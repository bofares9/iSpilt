import SwiftUI

@main
struct iSpiltApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
