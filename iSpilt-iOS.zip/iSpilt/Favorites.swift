import SwiftUI

struct Favorite: Codable, Identifiable, Equatable {
    var id = UUID()
    var title: String
    var url: String

    var letter: String { String(title.prefix(1)).uppercased() }
    var color: Color { Favorite.color(for: title) }

    static let palette: [Color] = [
        Color(red: 0.26, green: 0.52, blue: 0.96),
        Color(red: 0.90, green: 0.20, blue: 0.18),
        Color(red: 0.95, green: 0.42, blue: 0.11),
        Color(red: 0.11, green: 0.11, blue: 0.12),
        Color(red: 0.39, green: 0.39, blue: 0.40),
        Color(red: 0.20, green: 0.66, blue: 0.33),
        Color(red: 0.55, green: 0.33, blue: 0.85),
        Color(red: 0.18, green: 0.60, blue: 0.70)
    ]

    static func color(for text: String) -> Color {
        let sum = text.unicodeScalars.reduce(0) { $0 + Int($1.value) }
        return palette[sum % palette.count]
    }
}

final class FavoritesStore: ObservableObject {
    @Published var items: [Favorite] {
        didSet { save() }
    }

    private let key = "favorites.v1"

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([Favorite].self, from: data) {
            items = saved
        } else {
            items = [
                Favorite(title: "Google", url: "https://www.google.com"),
                Favorite(title: "YouTube", url: "https://m.youtube.com"),
                Favorite(title: "SoundCloud", url: "https://m.soundcloud.com"),
                Favorite(title: "X", url: "https://x.com"),
                Favorite(title: "ويكيبيديا", url: "https://ar.wikipedia.org")
            ]
        }
    }

    func add(title: String, url: String) {
        guard let resolved = URLInput.resolve(url) else { return }
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        var host = resolved.host ?? resolved.absoluteString
        if host.hasPrefix("www.") { host = String(host.dropFirst(4)) }
        items.append(Favorite(title: name.isEmpty ? host : name, url: resolved.absoluteString))
    }

    func remove(_ fav: Favorite) {
        items.removeAll { $0.id == fav.id }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
