import SwiftUI

/// صفحة وحدة بزوايا دائرية، فيها مقبض صغير (⋯) يطلّع الشريط المخفي.
struct PaneView: View {
    @ObservedObject var model: BrowserModel
    @ObservedObject var favs: FavoritesStore
    let radius: CGFloat
    let barAtBottom: Bool
    let bottomExtra: CGFloat
    /// زر ⋯ في الزاوية اليمين (للصفحة اليمين بالعرض) عشان يكون بعيد عن الفاصل
    var handleOnRight: Bool = false
    let onExpand: () -> Void
    let onSwap: () -> Void

    @State private var showBar = false
    @State private var text = ""
    @State private var hideWork: DispatchWorkItem?
    @FocusState private var editing: Bool

    /// المسافة من الحافة عشان المقبض والشريط ما ينقصّون مع دوران الزاوية
    private var inset: CGFloat { max(12, radius * 0.3) }
    private var verticalEdge: Edge.Set { barAtBottom ? .bottom : .top }

    var body: some View {
        ZStack {
            Color(.secondarySystemGroupedBackground)

            WebViewRep(webView: model.webView)
                .opacity(model.showingStart ? 0 : 1)
                .allowsHitTesting(!model.showingStart)

            if model.showingStart {
                StartPage(favs: favs, topPadding: barAtBottom ? inset + 8 : inset + 44) { input in
                    model.open(input)
                }
                .transition(.opacity)
            }
        }
        .overlay(alignment: .top) { progressLine }
        .overlay(alignment: barAtBottom ? .bottomTrailing : (handleOnRight ? .topLeading : .topTrailing)) { handle }
        .overlay(alignment: barAtBottom ? .bottom : .top) {
            if showBar {
                bar.transition(.move(edge: barAtBottom ? .bottom : .top).combined(with: .opacity))
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onReceive(model.scrolled) { _ in
            if showBar && !editing { hideNow() }
        }
        .onChange(of: editing) { isEditing in
            if isEditing {
                text = model.showingStart ? "" : (model.url?.absoluteString ?? "")
                hideWork?.cancel()
            } else {
                scheduleHide()
            }
        }
    }

    // MARK: - Handle (⋯)

    private var handle: some View {
        Group {
            if !showBar {
                Button(action: revealBar) {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.primary)
                        .frame(width: 32, height: 32)
                        .glassCircle()
                        .frame(width: 44, height: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("إظهار الشريط")
                .padding(.horizontal, inset - 6)
                .padding(verticalEdge, inset - 6 + (barAtBottom ? bottomExtra : 0))
                .transition(.opacity)
            }
        }
    }

    // MARK: - Bar

    private var fieldText: Binding<String> {
        Binding(
            get: { editing ? text : (model.showingStart ? "" : model.host) },
            set: { text = $0 }
        )
    }

    private var bar: some View {
        HStack(spacing: 2) {
            barButton("chevron.backward", label: "رجوع") {
                model.goBack()
            }
            .disabled(model.showingStart && !model.canGoBack)

            TextField("ابحث أو أدخل عنوانًا", text: fieldText)
                .focused($editing)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .submitLabel(.go)
                .multilineTextAlignment(.center)
                .font(.system(size: 15))
                .environment(\.layoutDirection, .leftToRight)
                .padding(.horizontal, 10)
                .frame(height: 36)
                .background(Color(.tertiarySystemFill), in: Capsule())
                .onSubmit {
                    model.open(text)
                    editing = false
                }

            barButton(model.isLoading ? "xmark" : "arrow.clockwise",
                      label: model.isLoading ? "إيقاف" : "تحديث") {
                model.reloadOrStop()
            }
            .disabled(model.showingStart)

            barButton("arrow.up.left.and.arrow.down.right", label: "ملء الشاشة") {
                hideNow()
                onExpand()
            }

            Menu {
                Button {
                    if let u = model.url { Share.present([u]) }
                } label: {
                    Label("مشاركة", systemImage: "square.and.arrow.up")
                }
                .disabled(model.showingStart || model.url == nil)

                Button {
                    model.goForward()
                } label: {
                    Label("للأمام", systemImage: "chevron.forward")
                }
                .disabled(!model.canGoForward && !(model.showingStart && model.url != nil))

                Button {
                    model.goHome()
                } label: {
                    Label("صفحة البداية", systemImage: "house")
                }

                Button {
                    if let u = model.url {
                        favs.add(title: model.title, url: u.absoluteString)
                        Haptics.success()
                    }
                } label: {
                    Label("إضافة للمفضلة", systemImage: "star")
                }
                .disabled(model.showingStart || model.url == nil)

                Button {
                    if let u = model.url { UIApplication.shared.open(u) }
                } label: {
                    Label("فتح في Safari", systemImage: "safari")
                }
                .disabled(model.showingStart || model.url == nil)

                Divider()

                Button {
                    hideNow()
                    onSwap()
                } label: {
                    Label("تبديل الصفحتين", systemImage: "arrow.up.arrow.down")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 18, weight: .regular))
                    .frame(width: 36, height: 36)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("المزيد")
        }
        .foregroundStyle(.primary)
        .padding(.horizontal, 6)
        .frame(height: 50)
        .glassCapsule()
        .padding(.horizontal, inset - 4)
        .padding(verticalEdge, inset - 6 + (barAtBottom ? bottomExtra : 0))
        .simultaneousGesture(TapGesture().onEnded {
            if !editing { scheduleHide() }
        })
    }

    private func barButton(_ icon: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: {
            action()
            scheduleHide()
        }) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .medium))
                .frame(width: 36, height: 36)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    // MARK: - Progress

    private var progressLine: some View {
        Group {
            if model.isLoading && !model.showingStart {
                GeometryReader { g in
                    Capsule()
                        .fill(Color.accentColor)
                        .frame(width: max(8, g.size.width * CGFloat(model.progress)), height: 3)
                        .animation(.easeOut(duration: 0.2), value: model.progress)
                }
                .frame(height: 3)
                .padding(.horizontal, radius * 0.7)
                .padding(.top, 2)
                .transition(.opacity)
            }
        }
    }

    // MARK: - Show / hide

    private func revealBar() {
        Haptics.light()
        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { showBar = true }
        scheduleHide()
    }

    private func hideNow() {
        hideWork?.cancel()
        editing = false
        withAnimation(.easeOut(duration: 0.22)) { showBar = false }
    }

    private func scheduleHide() {
        hideWork?.cancel()
        let work = DispatchWorkItem {
            if !editing {
                withAnimation(.easeOut(duration: 0.25)) { showBar = false }
            }
        }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute: work)
    }
}

/// شكل الصفحة لما تنسحب لآخرها: شريط صغير تضغطه وترجع الصفحتين.
struct CollapsedStrip: View {
    @ObservedObject var model: BrowserModel
    let vertical: Bool
    let onRestore: () -> Void

    var body: some View {
        Button(action: onRestore) {
            ZStack {
                Color(.secondarySystemGroupedBackground)
                if vertical {
                    VStack(spacing: 12) {
                        tile
                        Image(systemName: "arrow.left.and.right")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                } else {
                    HStack(spacing: 10) {
                        tile
                        Text(model.label)
                            .font(.subheadline)
                            .lineLimit(1)
                        Image(systemName: "arrow.up.and.down")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .buttonStyle(.plain)
        .environment(\.layoutDirection, .rightToLeft)
        .accessibilityLabel("إرجاع الصفحة الثانية")
    }

    private var tile: some View {
        RoundedRectangle(cornerRadius: 6, style: .continuous)
            .fill(Favorite.color(for: model.label))
            .frame(width: 24, height: 24)
            .overlay(
                Text(String(model.label.prefix(1)).uppercased())
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
            )
    }
}
