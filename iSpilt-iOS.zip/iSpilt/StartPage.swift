import SwiftUI

struct StartPage: View {
    @ObservedObject var favs: FavoritesStore
    let topPadding: CGFloat
    let onOpen: (String) -> Void

    @State private var query = ""
    @State private var showAdd = false

    private let columns = [GridItem(.adaptive(minimum: 68, maximum: 96), spacing: 8)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("ابحث في Google أو أدخل عنوانًا", text: $query)
                        .keyboardType(.webSearch)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                        .submitLabel(.go)
                        .onSubmit {
                            let q = query
                            query = ""
                            onOpen(q)
                        }
                }
                .padding(.horizontal, 12)
                .frame(height: 44)
                .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                Text("المفضلة")
                    .font(.title3.bold())

                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(favs.items) { fav in
                        FavTile(fav: fav) { onOpen(fav.url) }
                            .contextMenu {
                                Button(role: .destructive) {
                                    favs.remove(fav)
                                } label: {
                                    Label("حذف", systemImage: "trash")
                                }
                            }
                    }
                    AddTile { showAdd = true }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, topPadding)
            .padding(.bottom, 28)
        }
        .sheet(isPresented: $showAdd) {
            AddFavoriteView { title, url in favs.add(title: title, url: url) }
        }
    }
}

struct FavTile: View {
    let fav: Favorite
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(fav.color)
                    .frame(width: 58, height: 58)
                    .overlay(
                        Text(fav.letter)
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(.white)
                    )
                Text(fav.title)
                    .font(.caption2)
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }
}

struct AddTile: View {
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(Color(.tertiarySystemFill))
                    .frame(width: 58, height: 58)
                    .overlay(
                        Image(systemName: "plus")
                            .font(.system(size: 22, weight: .medium))
                            .foregroundStyle(.secondary)
                    )
                Text("إضافة")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("إضافة للمفضلة")
    }
}

struct AddFavoriteView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var url = ""
    let onSave: (String, String) -> Void

    var body: some View {
        NavigationView {
            Form {
                TextField("الاسم", text: $title)
                TextField("الرابط", text: $url)
                    .keyboardType(.URL)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .environment(\.layoutDirection, .leftToRight)
            }
            .navigationTitle("إضافة للمفضلة")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("حفظ") {
                        onSave(title, url)
                        dismiss()
                    }
                    .disabled(url.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
