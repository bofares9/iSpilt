import SwiftUI
import UIKit

// MARK: - Screen corner radius (يتبع دوران زوايا شاشة الجهاز)

enum ScreenCorner {
    static let radius: CGFloat = {
        let screen = UIScreen.main
        let selector = NSSelectorFromString("_displayCornerRadius")
        if screen.responds(to: selector),
           let value = screen.value(forKey: "_displayCornerRadius") as? CGFloat,
           value > 0 {
            return value
        }
        return 18 // أجهزة الشاشة المربعة مثل SE
    }()
}

// MARK: - Address bar input

enum URLInput {
    static func resolve(_ raw: String) -> URL? {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return nil }
        if let u = URL(string: s), let scheme = u.scheme?.lowercased(),
           scheme == "http" || scheme == "https", u.host != nil {
            return u
        }
        if !s.contains(" "), s.contains("."), let u = URL(string: "https://" + s), u.host != nil {
            return u
        }
        var c = URLComponents(string: "https://www.google.com/search")!
        c.queryItems = [URLQueryItem(name: "q", value: s)]
        return c.url
    }
}

// MARK: - Haptics

enum Haptics {
    static func light() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func snap() { UIImpactFeedbackGenerator(style: .rigid).impactOccurred() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}

// MARK: - Share sheet

enum Share {
    static func present(_ items: [Any]) {
        guard let scene = UIApplication.shared.connectedScenes.first(where: { $0 is UIWindowScene }) as? UIWindowScene,
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController ?? scene.windows.first?.rootViewController
        else { return }
        var top = root
        while let p = top.presentedViewController { top = p }
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = top.view
        top.present(vc, animated: true)
    }
}

// MARK: - Glass (Liquid Glass على iOS 26، وضبابي على الأقدم)

extension View {
    @ViewBuilder
    func glassCapsule() -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Capsule())
        } else {
            self
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                .shadow(color: Color.black.opacity(0.15), radius: 12, x: 0, y: 4)
        }
    }

    @ViewBuilder
    func glassCircle() -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Circle())
        } else {
            self
                .background(.ultraThinMaterial, in: Circle())
                .shadow(color: Color.black.opacity(0.12), radius: 6, x: 0, y: 2)
        }
    }
}
