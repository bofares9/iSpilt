import SwiftUI

/// أماكن الصفحتين والفاصل حسب وضع الجوال ونسبة التقسيم.
struct SplitLayout {
    let first: CGRect
    let second: CGRect
    let divider: CGRect
    let firstCollapsed: Bool
    let secondCollapsed: Bool
    let avail: CGFloat

    init(area: CGRect, landscape: Bool, ratio: Double, gap: CGFloat, strip: CGFloat) {
        let total = landscape ? area.width : area.height
        let avail = max(total - gap, strip * 2 + 1)
        var len: CGFloat
        var fc = false
        var sc = false
        if ratio <= 0 {
            len = strip
            fc = true
        } else if ratio >= 1 {
            len = avail - strip
            sc = true
        } else {
            len = min(max(avail * CGFloat(ratio), strip), avail - strip)
        }
        self.avail = avail
        self.firstCollapsed = fc
        self.secondCollapsed = sc
        if landscape {
            first = CGRect(x: area.minX, y: area.minY, width: len, height: area.height)
            divider = CGRect(x: area.minX + len, y: area.minY, width: gap, height: area.height)
            second = CGRect(x: area.minX + len + gap, y: area.minY, width: avail - len, height: area.height)
        } else {
            first = CGRect(x: area.minX, y: area.minY, width: area.width, height: len)
            divider = CGRect(x: area.minX, y: area.minY + len, width: area.width, height: gap)
            second = CGRect(x: area.minX, y: area.minY + len + gap, width: area.width, height: avail - len)
        }
    }
}

struct RootView: View {
    @StateObject private var pageA = BrowserModel(id: 0)
    @StateObject private var pageB = BrowserModel(id: 1)
    @StateObject private var favs = FavoritesStore()

    @AppStorage("ratio.portrait") private var ratioPortrait: Double = 0.5
    @AppStorage("ratio.landscape") private var ratioLandscape: Double = 0.5
    @AppStorage("swapped") private var swapped = false

    @State private var liveRatio: Double?
    @State private var dragStart: Double?
    @State private var snapped = false

    private let gap: CGFloat = 12
    private let strip: CGFloat = 52
    private let edge: CGFloat = 6
    private let spring = Animation.spring(response: 0.36, dampingFraction: 0.86)

    /// زاوية الصفحة = زاوية الشاشة ناقص المسافة من الحافة، عشان تكون متوازية معها
    private var paneRadius: CGFloat { max(12, ScreenCorner.radius - edge) }

    var body: some View {
        GeometryReader { geo in
            let s = geo.safeAreaInsets
            let size = geo.size
            let landscape = size.width > size.height
            let top = landscape ? edge : s.top + 2
            let left = landscape ? max(s.leading, edge) : edge
            let right = landscape ? max(s.trailing, edge) : edge
            let bottom = landscape ? max(s.bottom, edge) : edge
            let area = CGRect(x: left, y: top,
                              width: max(size.width - left - right, 1),
                              height: max(size.height - top - bottom, 1))
            let layout = SplitLayout(area: area, landscape: landscape,
                                     ratio: liveRatio ?? storedRatio(landscape),
                                     gap: gap, strip: strip)
            let homeExtra = landscape ? 0 : max(s.bottom - 12, 0)

            ZStack(alignment: .topLeading) {
                Color.black
                pane(pageA, slot: swapped ? 1 : 0, layout: layout, landscape: landscape, homeExtra: homeExtra)
                pane(pageB, slot: swapped ? 0 : 1, layout: layout, landscape: landscape, homeExtra: homeExtra)
                dividerView(layout, landscape: landscape)
            }
            .frame(width: size.width, height: size.height, alignment: .topLeading)
            .environment(\.layoutDirection, .leftToRight)
        }
        .ignoresSafeArea(.container)
        .background(Color.black.ignoresSafeArea())
    }

    // MARK: - Pane

    @ViewBuilder
    private func pane(_ model: BrowserModel, slot: Int, layout: SplitLayout, landscape: Bool, homeExtra: CGFloat) -> some View {
        let rect = slot == 0 ? layout.first : layout.second
        let collapsed = liveRatio == nil && (slot == 0 ? layout.firstCollapsed : layout.secondCollapsed)
        let isBottom = !landscape && slot == 1

        PaneView(model: model,
                 favs: favs,
                 radius: paneRadius,
                 barAtBottom: isBottom,
                 bottomExtra: isBottom ? homeExtra : 0,
                 onExpand: { expand(slot: slot, landscape: landscape) },
                 onSwap: { withAnimation(spring) { swapped.toggle() } })
            .overlay {
                if collapsed {
                    CollapsedStrip(model: model, vertical: landscape) { restore(landscape) }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: collapsed ? min(paneRadius, strip / 2) : paneRadius,
                                        style: .continuous))
            .frame(width: rect.width, height: rect.height)
            .offset(x: rect.minX, y: rect.minY)
    }

    // MARK: - Divider

    private func dividerView(_ layout: SplitLayout, landscape: Bool) -> some View {
        let d = layout.divider
        let hit = landscape ? d.insetBy(dx: -8, dy: 0) : d.insetBy(dx: 0, dy: -8)
        return ZStack {
            Color.black.opacity(0.001)
            Capsule()
                .fill(Color.white.opacity(liveRatio == nil ? 0.4 : 0.85))
                .frame(width: landscape ? 5 : 40, height: landscape ? 40 : 5)
        }
        .frame(width: hit.width, height: hit.height)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { restore(landscape) }
        .gesture(dragGesture(landscape: landscape, avail: layout.avail))
        .offset(x: hit.minX, y: hit.minY)
        .accessibilityLabel("الفاصل")
        .accessibilityHint("اسحب لتغيير حجم الصفحتين، واضغط مرتين للتوسيط")
    }

    private func dragGesture(landscape: Bool, avail: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 1, coordinateSpace: .global)
            .onChanged { value in
                if dragStart == nil {
                    let r = storedRatio(landscape)
                    let minR = Double(strip / avail)
                    dragStart = r <= 0 ? minR : (r >= 1 ? 1 - minR : r)
                }
                let t = landscape ? value.translation.width : value.translation.height
                var r = (dragStart ?? 0.5) + Double(t / avail)
                r = min(max(r, 0.0001), 0.9999)
                if abs(r - 0.5) < 0.02 {
                    r = 0.5
                    if !snapped {
                        Haptics.snap()
                        snapped = true
                    }
                } else {
                    snapped = false
                }
                liveRatio = r
            }
            .onEnded { _ in
                var r = liveRatio ?? storedRatio(landscape)
                if r < 0.14 {
                    r = 0
                    Haptics.snap()
                } else if r > 0.86 {
                    r = 1
                    Haptics.snap()
                }
                withAnimation(spring) {
                    setRatio(r, landscape)
                    liveRatio = nil
                }
                dragStart = nil
                snapped = false
            }
    }

    // MARK: - Ratio

    private func storedRatio(_ landscape: Bool) -> Double {
        landscape ? ratioLandscape : ratioPortrait
    }

    private func setRatio(_ r: Double, _ landscape: Bool) {
        if landscape { ratioLandscape = r } else { ratioPortrait = r }
    }

    private func restore(_ landscape: Bool) {
        Haptics.light()
        withAnimation(spring) { setRatio(0.5, landscape) }
    }

    private func expand(slot: Int, landscape: Bool) {
        Haptics.light()
        withAnimation(spring) { setRatio(slot == 0 ? 1 : 0, landscape) }
    }
}
