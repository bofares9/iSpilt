import SwiftUI
import WebKit
import Combine

/// صفحة متصفح وحدة. كل صفحة لها WKWebView خاص فيها يبقى حي طول ما التطبيق مفتوح.
@MainActor
final class BrowserModel: NSObject, ObservableObject {
    let id: Int
    let webView: WKWebView

    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var title = ""
    @Published var url: URL?
    @Published var showingStart = true

    /// يرسل إشارة أول ما المستخدم يبدأ يمرر الصفحة (عشان نخفي الشريط)
    let scrolled = PassthroughSubject<Void, Never>()

    private var bag = Set<AnyCancellable>()
    private var storageKey: String { "pane.\(id).url" }

    init(id: Int) {
        self.id = id
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.websiteDataStore = .default()
        let web = WKWebView(frame: .zero, configuration: config)
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false
        web.backgroundColor = .clear
        self.webView = web
        super.init()

        web.navigationDelegate = self
        web.uiDelegate = self
        web.scrollView.panGestureRecognizer.addTarget(self, action: #selector(handlePan(_:)))
        bind()

        if let saved = UserDefaults.standard.string(forKey: storageKey), let u = URL(string: saved) {
            showingStart = false
            web.load(URLRequest(url: u))
        }
    }

    private func bind() {
        webView.publisher(for: \.canGoBack)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.canGoBack = $0 }
            .store(in: &bag)
        webView.publisher(for: \.canGoForward)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.canGoForward = $0 }
            .store(in: &bag)
        webView.publisher(for: \.isLoading)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.isLoading = $0 }
            .store(in: &bag)
        webView.publisher(for: \.estimatedProgress)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.progress = $0 }
            .store(in: &bag)
        webView.publisher(for: \.title)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in self?.title = $0 ?? "" }
            .store(in: &bag)
        webView.publisher(for: \.url)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] value in
                guard let self = self else { return }
                self.url = value
                if let value = value, !self.showingStart {
                    UserDefaults.standard.set(value.absoluteString, forKey: self.storageKey)
                }
            }
            .store(in: &bag)
    }

    @objc private func handlePan(_ g: UIPanGestureRecognizer) {
        if g.state == .began { scrolled.send() }
    }

    var host: String {
        guard let h = url?.host else { return "" }
        return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
    }

    var label: String { showingStart ? "صفحة البداية" : (host.isEmpty ? "صفحة" : host) }

    func open(_ input: String) {
        guard let u = URLInput.resolve(input) else { return }
        open(url: u)
    }

    func open(url: URL) {
        showingStart = false
        webView.load(URLRequest(url: url))
    }

    func goBack() {
        if webView.canGoBack {
            webView.goBack()
        } else if !showingStart {
            goHome()
        }
    }

    func goForward() {
        if showingStart, url != nil {
            showingStart = false
        } else if webView.canGoForward {
            webView.goForward()
        }
    }

    func reloadOrStop() {
        if isLoading { webView.stopLoading() } else { webView.reload() }
    }

    func goHome() {
        webView.stopLoading()
        showingStart = true
        UserDefaults.standard.removeObject(forKey: storageKey)
    }
}

extension BrowserModel: WKNavigationDelegate, WKUIDelegate {
    // الروابط اللي تفتح بنافذة جديدة (target=_blank) تنفتح بنفس الصفحة
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }

    // روابط مثل tel: و mailto: وروابط المتجر تنفتح بالنظام
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let u = navigationAction.request.url, let scheme = u.scheme?.lowercased(),
           !["http", "https", "about", "data", "blob", "file", "javascript"].contains(scheme) {
            UIApplication.shared.open(u)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
}
